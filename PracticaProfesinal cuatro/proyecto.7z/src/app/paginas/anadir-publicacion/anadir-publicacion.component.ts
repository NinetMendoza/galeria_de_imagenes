import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-anadir-publicacion',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './anadir-publicacion.component.html'
})
export class AnadirPublicacionComponent {}
