import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-formulario-registro',
  imports: [RouterLink],
  templateUrl: './formulario-registro.component.html'
})
export class FormularioRegistroComponent {}
