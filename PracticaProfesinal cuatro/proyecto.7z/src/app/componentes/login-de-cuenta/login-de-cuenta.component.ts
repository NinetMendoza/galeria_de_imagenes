import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login-de-cuenta',
  imports: [RouterLink],
  templateUrl: './login-de-cuenta.component.html'
})
export class LoginDeCuentaComponent {}
