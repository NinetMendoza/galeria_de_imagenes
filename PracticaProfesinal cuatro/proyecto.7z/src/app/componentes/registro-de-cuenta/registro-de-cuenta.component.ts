import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-registro-de-cuenta',
  imports: [RouterLink],
  templateUrl: './registro-de-cuenta.component.html'
})
export class RegistroDeCuentaComponent {}
